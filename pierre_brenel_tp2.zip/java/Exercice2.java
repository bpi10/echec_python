/* Affichez les tables de multiplication de 1 à 9. Vous utiliserez les instructions System.out.print
et System.out.println vue dans le premier TP. Vous écrirez une nouvelle classe Tables */
class Exercice2 {
    public static void main(String[] args){
        int x;
        int y;

        for(x = 1 ; x <= 9; x++){
            for(y = 1 ; y <= 9; y++){
                System.out.print(x * y + "  |  ");
            }
        System.out.println();
        }
    }
}
