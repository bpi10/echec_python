/* Ecrivez une nouvelle classe Somme. En utilisant la méthode next() de la classe Scanner,
récupérez deux chaines de caractères. On suppose que ces chaînes de caractères sont des
nombres entiers. Affichez la somme de ces nombres. 
Entrez un nombre :
5
Entrez un deuxième nombre :
8
5+8=13
*/ 

import java.util.Scanner;

class Somme{
    public static void main(String[] args){
    
    Scanner sc = new Scanner(System.in);
    System.out.println("Entrer un nombre :");
    int first = sc.nextInt();
    System.out.println("Entrer un deuxieme nombre :");
    int second = sc.nextInt();
    int addition = first + second;
    System.out.println(first + " + " + second  + " = " + addition);
    }
}