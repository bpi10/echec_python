/*Affichez les entiers entre 1 et 9 dans la méthode main d’une classe Entier que vous
écrirez. Le programme affichera à la fin la somme et le produit de ces nombres.*/
class Exercice1 {
    public static void main(String[] args){
        int i;
        int somme;
        int produit;
        
        somme = 0;
        produit = 0;
        i = 1;
        while (i <= 9) { 
	        somme = somme + i;
            produit = produit * i;
	        i = i + 1;
        }
        System.out.println("Voila la somme des 9 premiers entiers : " + somme);
        System.out.println("Voilà le produit des 9 premiers entiers : " + produit);
    }
}
