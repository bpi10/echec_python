// Ecrivez une nouvelle classe SommeN qui permet de saisir une série d’entiers terminés par
//la chaine "fin".La moyenne de tous les entiers saisis est affichée à la fin.
//Exemple d’exécution :
//java SommeN
//Entrez un nombre (ou fin pour terminer)
//12
//Entrez un nombre (ou fin pour terminer)
//13
//Entrez un nombre (ou fin pour terminer)
//14
//Entrez un nombre (ou fin pour terminer)
//fin
//Somme = 39
//Moyenne = 13


import java.util.Scanner;

class SommeN{
    public static void main(String[] args){
    
    int sortir = 147258;
    int Somme = 0;
    int Moyenne = 0;
    Scanner sc = new Scanner(System.in);

    while(!sc.equals(sortir)){
        /*Scanner sc = new Scanner(System.in);*/
        System.out.println("Entrer un nombre :");
        int nombre = sc.nextInt();
        Somme += nombre;
        Moyenne += nombre / (length.nombre); 
        if (nombre == sortir){
            System.out.println("fin");
            System.out.println("Somme" + "=" + (Somme - 147258));
            System.out.println("Moyenne" + "=" + (Moyenne - 147258));
        }

    }
    }
}
    