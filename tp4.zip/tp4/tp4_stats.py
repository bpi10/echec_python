#***********************************#
#              TP4 STATS            #
#            BRENEL Pierre          #
#***********************************#

# Sources
# https://moncoachdata.com/blog/guide-bibliotheque-pandas/
# http://www.python-simple.com/python-pandas/fonctions-dataframe.php

# https://moonbooks.org/Articles/Simple-diagramme-circulaire-avec-matplotlib/
# http://www.python-simple.com/python-matplotlib/barplot.php
# https://moonbooks.org/Articles/Comment-lire-un-fichier-excel-extension-xlsx-avec-pandas-en-python-/


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

df = pd.read_excel("Tp4partie1.xlsx")
# print (df)
 
labels = df['nom complet']
sizes = df['promo 2018']
colors = ['yellowgreen', 'gold', 'lightskyblue', 'lightcoral', 'orange']
explode = (0, 0.2, 0, 0, 0)
title = 'l’insertion professionnelle à l’issue du bac +5 en 2018'

plt.pie(sizes, explode = explode, labels = labels, colors = colors, autopct = '%1.1f%%', shadow = True, startangle = 90)
plt.axis('equal')
plt.savefig('graphique_tp4_partie1.png')
plt.gca().title.set_text(title)


labels = df['nom complet']
sizes = df['promo 2019']
colors = ['yellowgreen', 'gold', 'lightskyblue', 'lightcoral', 'orange']
explode = (0, 0.2, 0, 0,0)
title = 'l’insertion professionnelle à l’issue du bac +5 en 2019'

plt.pie(sizes, explode = explode, labels = labels, colors = colors, autopct = '%1.1f%%', shadow = True, startangle = 90)
plt.axis('equal')
plt.gca().title.set_text(title)
# plt.subplot(130)
plt.show()