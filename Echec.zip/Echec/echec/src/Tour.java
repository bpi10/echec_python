/*******************************/ 
/*          classe Tour        */
/*         Pierre Brenel       */
/*             ECHEC           */
/*******************************/
import java.util.ArrayList;

public class Tour extends Piece{
    
    public Tour() {
        setCouleur('B');
        setPosition(new Position("A1"));
    }

    public Tour(char couleur,String position) {
        setCouleur(couleur);
        setPosition(new Position(position));
    }

    public String getType() {
        return "tour";
    }

    public ArrayList<Position> getDeplacementPossible(Plateau plateau) {
        ArrayList <Position> tableau = new ArrayList<Position>();
        int i=getPosition().getX();
        int j = getPosition().getY();
        int compteur = 0;
        j = j+1;
        while((plateau.getCase(i,j)==null || plateau.getCase(i,j).getCouleur()!= getCouleur()) && compteur == 0 && j<9 )
        {
            if (plateau.getCase(i,j)==null){
                tableau.add(new Position(i,j));
                j= j+1;
            }
            else if(plateau.getCase(i,j).getCouleur()!= getCouleur()){
                compteur = 1;
                tableau.add(plateau.getCase(i,j).getPosition());
                j= j+1;
            }
            else{
            compteur = 0;
            tableau.add(plateau.getCase(i,j).getPosition());
            j= j+1;
            }
        }
        i=getPosition().getX();
        j = getPosition().getY();
        compteur = 0;
        j = j-1;
        while((plateau.getCase(i,j)==null || plateau.getCase(i,j).getCouleur()!= getCouleur()) && compteur == 0 && j>0 )
        {
            if (plateau.getCase(i,j)==null){
                tableau.add(new Position(i,j));
                j= j-1;
            }
            else if(plateau.getCase(i,j).getCouleur()!= getCouleur()){
                compteur = 1;
                tableau.add(plateau.getCase(i,j).getPosition());
                j= j-1;
            }
            else{
            compteur = 0;
            tableau.add(plateau.getCase(i,j).getPosition());
            j= j-1;
            }
        }
        i=getPosition().getX();
        j = getPosition().getY();
        compteur = 0;
        i = i-1;
        while((plateau.getCase(i,j)==null || plateau.getCase(i,j).getCouleur()!= getCouleur()) && compteur == 0 && i>0 ){
            if (plateau.getCase(i,j)==null){
                tableau.add(new Position(i,j));
                i= i-1;
            }
            else if(plateau.getCase(i,j).getCouleur()!= getCouleur()){
                compteur = 1;
                tableau.add(plateau.getCase(i,j).getPosition());
                i= i-1;
            }
            else{
            compteur = 0;
            tableau.add(plateau.getCase(i,j).getPosition());
            i= i-1;
            }
        }
        i=getPosition().getX();
        j = getPosition().getY();
        compteur = 0;
        i = i+1;
        while((plateau.getCase(i,j)==null || plateau.getCase(i,j).getCouleur()!= getCouleur()) && compteur == 0 && i<9 ){
            if (plateau.getCase(i,j)==null){
                tableau.add(new Position(i,j));
                i = i+1;
            }
            else if(plateau.getCase(i,j).getCouleur()!= getCouleur()){
                compteur = 1;
                tableau.add(plateau.getCase(i,j).getPosition());
                i = i+1;
            }
            else{
            compteur = 0;
            tableau.add(plateau.getCase(i,j).getPosition());
            i = i+1;
            }
        }
        return tableau;
    }



    public ArrayList<Position> getDeplacementPossibleEchec(Plateau plateau) {
        ArrayList <Position> tableau = new ArrayList<Position>();
        int i=getPosition().getX();
        int j = getPosition().getY();
        int compteur = 0;
        j = j+1;
        while((plateau.getCase(i,j)==null || plateau.getCase(i,j).getCouleur()!= getCouleur()) && compteur == 0 && j<9 ){
            if (plateau.getCase(i,j)==null){
                tableau.add(new Position(i,j));
                j= j+1;
            }
            else if(plateau.getCase(i,j).getCouleur()!= getCouleur()){
                compteur = 1;
                tableau.add(plateau.getCase(i,j).getPosition());
                j= j+1;
            }
            else{
            compteur = 0;
            tableau.add(plateau.getCase(i,j).getPosition());
            j= j+1;
            }
        }
        i=getPosition().getX();
        j = getPosition().getY();
        compteur = 0;
        j = j-1;
        while((plateau.getCase(i,j)==null || plateau.getCase(i,j).getCouleur()!= getCouleur()) && compteur == 0 && j>0 ){
            if (plateau.getCase(i,j)==null){
                tableau.add(new Position(i,j));
                j= j-1;
            }
            else if(plateau.getCase(i,j).getCouleur()!= getCouleur())
            {
                compteur = 1;
                tableau.add(plateau.getCase(i,j).getPosition());
                j= j-1;
            }
            else{
            compteur = 0;
            tableau.add(plateau.getCase(i,j).getPosition());
            j= j-1;
            }
        }
        i=getPosition().getX();
        j = getPosition().getY();
        compteur = 0;
        i = i-1;
        while((plateau.getCase(i,j)==null || plateau.getCase(i,j).getCouleur()!= getCouleur()) && compteur == 0 && i>0 ){
            if (plateau.getCase(i,j)==null) {
                tableau.add(new Position(i,j));
                i= i-1;
            }
            else if(plateau.getCase(i,j).getCouleur()!= getCouleur()){
                compteur = 1;
                tableau.add(plateau.getCase(i,j).getPosition());
                i= i-1;
            }
            else{
            compteur = 0;
            tableau.add(plateau.getCase(i,j).getPosition());
            i= i-1;
            }
        }
        i=getPosition().getX();
        j = getPosition().getY();
        compteur = 0;
        i = i+1;
        while((plateau.getCase(i,j)==null || plateau.getCase(i,j).getCouleur()!= getCouleur()) && compteur == 0 && i<9 ){
            if (plateau.getCase(i,j)==null){
                tableau.add(new Position(i,j));
                i = i+1;
            }
            else if(plateau.getCase(i,j).getCouleur()!= getCouleur()){
                compteur = 1;
                tableau.add(plateau.getCase(i,j).getPosition());
                i = i+1;
            }
            else{
            compteur = 0;
            tableau.add(plateau.getCase(i,j).getPosition());
            i = i+1;
            }
        }
        return tableau;
    }
}