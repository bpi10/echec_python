/*******************************/ 
/*       classe Position       */
/*         Pierre Brenel       */
/*             ECHEC           */
/*******************************/

public class Position {
    
    // attributs privés
    private int x, y;
    
    // constructeur par défaut qui intialisera les attributs à 0.
    public Position() {
        this.x = 0;
        this.y = 0;
    }

    // constructeur par copie.
    public Position (Position p) {
        this.x = p.x;
        this.y = p.y;
    }
    

    // Un constructeur prenant deux entiers en paramètres.
    public Position(int a, int b) {
        // Attention ! Vérifier que a et b soit compris entre 0 et 7
        if(a >= 0 && a <=7){
            this.x = a;
        }
        if(b >= 0 && b <=7){
            this.y = b;
        }
    }

    // Un constructeur prenant une chaine de caractère en paramètre. La chaine de caractère
    // en paramètre sera de la forme : lettre en majuscule suivie d’un chiffre 
    // (identification d’une case comme sur un échiquier).
    public Position(String str){
        int ligne =Integer.parseInt(String.valueOf(str.charAt(1))); 
        this.y=ligne - 1;
        this.x = (int)(str.charAt(0)-'A');
    }

    // getter
    public int getX() {
        return this.x;
    }

    
    public int getY() {
        return this.y;
    }

    // setter
    public void setX(int a) {
        // Attention ! Vérifier que a soit compris entre 0 et 7
        if(a >= 0 && a <=7){
            x = a;
        }
    }

    public void setY(int b) {
        // Attention ! Vérifier que b soit compris entre 0 et 7
        if(b >= 0 && b <=7){
            y = b;
        }
    }

    // méthode equals
    @Override
    public boolean equals(Object obj) {
         
        if(this == obj) return true;
        if (!(obj instanceof Position)) return false;
        Position pos = (Position) obj; // transforme obj en position
 
        if (this.x != (pos.x)) return false;
        if (this.y != (pos.y)) return false;
        return true;
 
    }

    //La méthode toString retournant la position sous la forme du repérage de l'échiquier
    public String toString() {
        String c = new String("lalala");
        String affichage_echec = c.substring(this.x , (this.x+1)) + (this.y);
        return affichage_echec;
    }

    public static void main(String[] args) {
        Position pos = new Position();
        System.out.println(pos);
    }
    
}  