/*******************************/ 
/*         classe Cavalier     */
/*         Pierre Brenel       */
/*             ECHEC           */
/*******************************/
import java.util.ArrayList;

public class Cavalier extends Piece{

    public Cavalier()
    {
        setCouleur('B');
        setPosition(new Position("B1"));
    }

    public Cavalier(char couleur , String position)
    {
        setCouleur(couleur);
        setPosition(new Position(position));
    }

    public String getType()
    {
        return "cavalier";
    }

    public ArrayList<Position>getDeplacementPossible(Plateau plateau) 
    {
        ArrayList <Position> tab = new ArrayList<Position>();
        int i = getPosition().getX();
        int j = getPosition().getY();
        if ((plateau.getCase(i+2,j+1)==null || plateau.getCase(i+2,j+1).getCouleur()!= getCouleur()) && i + 2 < 9 && j + 1 < 9)
            {
                tab.add(new Position(i+2,j+1));
            }
        if ((plateau.getCase(i+2,j-1)==null || plateau.getCase(i+2,j-1).getCouleur()!= getCouleur()) && i + 2 < 9 && j - 1 > 0)
            {
                tab.add(new Position(i+2,j-1));
            }
        if ((plateau.getCase(i-2,j-1)==null || plateau.getCase(i-2,j-1).getCouleur()!= getCouleur()) && i - 2 > 0 && j- 1 > 0 )
            {
                tab.add(new Position(i-2,j-1));
            }
        if ((plateau.getCase(i-2,j+1)==null || plateau.getCase(i-2,j+1).getCouleur()!= getCouleur()) &&i - 2 > 0 && j + 1 < 9)
            {
                tab.add(new Position(i-2,j+1));
            }

        if ((plateau.getCase(i+1,j+2)==null || plateau.getCase(i+1,j+2).getCouleur()!= getCouleur()) && i + 1 < 9 && j + 2 < 9)
            {
                tab.add(new Position(i+1,j+2));
            }

        if ((plateau.getCase(i+1,j-2)==null || plateau.getCase(i+1,j-2).getCouleur()!= getCouleur()) && i + 1 < 9 && j - 2 > 0)
            {
                tab.add(new Position(i+1,j-2));
            }
        if ((plateau.getCase(i-1,j-2)==null || plateau.getCase(i-1,j-2).getCouleur()!= getCouleur()) && i - 1 > 0 && j - 2 > 0 )
            {
                tab.add(new Position(i-1,j-2));
            }
        if ((plateau.getCase(i-1,j+2)==null || plateau.getCase(i-1,j+2).getCouleur()!= getCouleur()) && i - 1 > 0 && j + 2 < 9)
            {
                tab.add(new Position(i-1,j+2));
            }
        return tab;
    }

    public ArrayList<Position>getDeplacementPossibleEchec(Plateau plateau) 
    {
        ArrayList <Position> tableau = new ArrayList<Position>();
        int i=getPosition().getX();
        int j = getPosition().getY();
        if ((plateau.getCase(i+2,j+1)==null || plateau.getCase(i+2,j+1).getCouleur()!= getCouleur()) && i + 2 < 9 && j + 1 < 9)
            {
                tableau.add(new Position(i+2,j+1));
            }
        if ((plateau.getCase(i+2,j-1)==null || plateau.getCase(i+2,j-1).getCouleur() != getCouleur()) && i + 2 < 9 && j - 1 > 0)
            {
                tableau.add(new Position(i+2,j-1));
            }
        if ((plateau.getCase(i-2,j-1)==null || plateau.getCase(i-2,j-1).getCouleur() != getCouleur()) && i - 2 > 0 && j - 1 > 0)
            {
                tableau.add(new Position(i-2,j-1));
            }
        if ((plateau.getCase(i-2,j+1)==null || plateau.getCase(i-2,j+1).getCouleur() != getCouleur()) && i - 2 > 0 && j + 1 < 9)
            {
                tableau.add(new Position(i-2,j+1));
            }

        if ((plateau.getCase(i+1,j+2)==null || plateau.getCase(i+1,j+2).getCouleur() != getCouleur()) && i + 1 < 9 && j + 2 < 9)
            {
                tableau.add(new Position(i+1,j+2));
            }

        if ((plateau.getCase(i+1,j-2)==null || plateau.getCase(i+1,j-2).getCouleur() != getCouleur()) && i + 1 < 9 && j - 2 > 0)
            {
                tableau.add(new Position(i+1,j-2));
            }
        if ((plateau.getCase(i-1,j-2)==null || plateau.getCase(i-1,j-2).getCouleur() != getCouleur()) && i - 1 > 0 && j - 2 > 0)
            {
                tableau.add(new Position(i-1,j-2));
            }
        if ((plateau.getCase(i-1,j+2)==null || plateau.getCase(i-1,j+2).getCouleur() != getCouleur()) && i - 1 > 0 && j + 2 < 9)
            {
                tableau.add(new Position(i-1,j+2));
            }
        return tableau;
    }
}
