/*******************************/ 
/*         classe Pion         */
/*         Pierre Brenel       */
/*             ECHEC           */
/*******************************/
import java.util.ArrayList;

public abstract class Pion extends Piece {
    public String getType() {
        return "pion";
    }

    public abstract ArrayList<Position> getDeplacementPossible(Plateau plateau);

    public abstract ArrayList<Position> getDeplacementPossibleEchec(Plateau plateau);

}