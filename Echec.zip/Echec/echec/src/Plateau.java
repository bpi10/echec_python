/*******************************/ 
/*         classe Plateau      */
/*         Pierre Brenel       */
/*             ECHEC           */
/*******************************/
import java.util.ArrayList;

public class Plateau {
    // attributs privés
    private ArrayList<Piece> plateau;
    
    // constructeur par défaut
    public Plateau() {
        plateau = new ArrayList<Piece>();
        this.plateau.add(new Tour('B',"A1"));
        this.plateau.add(new Tour('B',"H1"));
        this.plateau.add(new Tour('N',"A8"));
        this.plateau.add(new Tour('N',"H8"));
        this.plateau.add(new Cavalier('B',"B1"));
        this.plateau.add(new Cavalier('B',"G1"));
        this.plateau.add(new Cavalier('N',"B8"));
        this.plateau.add(new Cavalier('N',"G8"));
        this.plateau.add(new Fou('B',"C1"));
        this.plateau.add(new Fou('B',"F1"));
        this.plateau.add(new Fou('N',"C8"));
        this.plateau.add(new Fou('N',"F8"));
        this.plateau.add(new Dame('B',"D1"));
        this.plateau.add(new Dame('N',"D8"));
        this.plateau.add(new Roi('B',"E1"));
        this.plateau.add(new Roi('N',"E8"));
        this.plateau.add(new PionBlanc("A2"));
        this.plateau.add(new PionBlanc("B2"));
        this.plateau.add(new PionBlanc("C2"));
        this.plateau.add(new PionBlanc("D2"));
        this.plateau.add(new PionBlanc("E2"));
        this.plateau.add(new PionBlanc("F2"));
        this.plateau.add(new PionBlanc("G2"));
        this.plateau.add(new PionBlanc("H2"));
        this.plateau.add(new PionNoir("A7"));
        this.plateau.add(new PionNoir("B7"));
        this.plateau.add(new PionNoir("C7"));
        this.plateau.add(new PionNoir("D7"));
        this.plateau.add(new PionNoir("E7"));
        this.plateau.add(new PionNoir("F7"));
        this.plateau.add(new PionNoir("G7"));
        this.plateau.add(new PionNoir("H7"));
    }

    // Trois méthodes getCase. L’une prend en paramètre deux entiers, la seconde un objet
    // de type Position et une dernière prenant une chaine de caractère indiquant une
    // positoin à la manière de l’échiquier. Cette méthode retournera un objet de type Piece.
    // Si une pièce se trouve à la position donnée, cette pièce sera retournée. Si aucune pièce
    // ne se trouve sur la case, la méthode retournera la valeur null indiquant ainsi que la
    // case est vide.


    public Piece getCase(int x , int y) {
        for (Piece piece : this.plateau) {
            if (piece.getPosition().equals(new Position(x,y))) {
                return piece;
            }
        }
        return null;
    }

    public Piece getCase(Position pos) {
        for (Piece p : this.plateau) {
            if (p.getPosition().equals(pos)) {
                return p;
            }
        }
        return null;
    }

    public Piece getCase(String pos) {
        for (Piece p : this.plateau) {
            if (p.getPosition().equals(new Position(pos))) {
                return p;
            }
        }
        return null;
    }



    // La méthode toString retournant le plateau tel que présenté en bas de la page 2.
    public String toString() { 
        int chiffre;
        chiffre = 8;
        System.out.print(" |---|---|---|---|---|---|---|---|\n");
        while (chiffre > 0) {
            if (chiffre !=8 ) {
                System.out.print(" |---|---|---|---|---|---|---|---|\n");
            }
            System.out.print(chiffre);
            for (int i = 0 ; i < 8 ; i++) {
                if(getCase(i+1,chiffre)==null) {
                    System.out.print( "|   ");
                }
                else { 
                    System.out.print( "|"+getCase(i + 1, chiffre).getNomCourt());
                }  
            }
            System.out.print( "|"+ chiffre +"\n");  
            chiffre = chiffre - 1;
        }
        System.out.print(" |---|---|---|---|---|---|---|---|\n");
        System.out.print("  A   B   C   D   E   F   G   H\n");
        return "\n";
    }


    // Une méthode getPiecesBlanches retournant un tableau dynamique rempli des pièces
    // blanches encore présentes sur le plateau
    public ArrayList<Piece> getPiecesBlanches() { 
        ArrayList<Piece> tab_Blanc = new ArrayList<Piece>();
        for (Piece piece : this.plateau) {
            if (piece.getCouleur()=='B') {
                tab_Blanc.add(piece);
            }
        }
        return tab_Blanc;
    }


    //  Une méthode getPiecesNoires retournant un tableau dynamique rempli des pièces
    // noires encore présentes sur le plateau.
    public ArrayList<Piece> getPiecesNoires()
    { 
        ArrayList<Piece> tab_Noir = new ArrayList<Piece>();
        for (Piece piece : this.plateau) {
            if (piece.getCouleur()=='N') {
                tab_Noir.add(piece);
            }
        }
        return tab_Noir;
    }

    public void remove(Piece piece) {
        this.plateau.remove(piece);
    }
    // Ajoutez une méthode qui va déplacer une pièce (si le dépalcement est possible seulement
    public Boolean deplacer( Position from, Position to ) {
        Piece p = getCase(from);
        ArrayList<Position> d = p.getDeplacementPossible(this);
        for (int i = 0; i < d.size(); i++){
            if (d.get(i).getX() == to.getX() && d.get(i).getY() == to.getY()) {
                this.remove((this.getCase(to)));
                return true;
            }
        }
        return false;
    }



    public ArrayList<ArrayList <Position>> getToutDeplacementPossible(Plateau p,char c) {
        ArrayList <ArrayList <Position>> tab = new ArrayList<ArrayList <Position>>();
        for (Piece piece : this.plateau)
        {
            if (piece.getCouleur() != c)
            {
            tab.add(piece.getDeplacementPossibleEchec(p));
            }
        }
        return tab;
    }

    // ajouter une méthode estEchec prenant en paramètre une
    // couleur. La méthode doit retourner vrai si le roi dont la couleur est passée en paramètre est
    // en échec.
    public boolean estEchec(Plateau plateau,char c) {
        for (Piece piece : this.plateau) {
            if (piece.getCouleur()== c && piece.getType()=="roi") {
                for(ArrayList<Position> list :plateau.getToutDeplacementPossible(plateau, c)) {
                    for(Position pos : list) {
                            if(pos.equals(piece.getPosition())) {
                                return true;
                            }
                    }
                }
            }
        }
        return false;
    }
}     