/*******************************/ 
/*        classe PionNoir      */
/*         Pierre Brenel       */
/*             ECHEC           */
/*******************************/
import java.util.ArrayList;

public class PionNoir extends Pion {
    public PionNoir() {
        setCouleur('N');
        setPosition(new Position("A1"));
    }

    public PionNoir(String position) {
        setCouleur('N');
        setPosition(new Position(position));
    }

    public String getType() {
        return "pion";
    }

    public ArrayList<Position> getDeplacementPossible(Plateau plateau) {
        ArrayList <Position> tableau = new ArrayList<Position>();
        int i = getPosition().getX();
        int j = getPosition().getY();
        if ((plateau.getCase(i,j-1)==null )&&j-1>0){
            tableau.add(new Position(i,j-1));
        }
        if ((plateau.getCase(i,j-2)==null && plateau.getCase(i,j-1)==null)&&j-2>0&&j==7){
            tableau.add(new Position(i,j-2));
        }
        if ((plateau.getCase(i+1,j-1)!=null && plateau.getCase(i+1,j-1).getCouleur()!=getCouleur())&&j-1>0&&i+1<9){
            tableau.add(new Position(i+1,j-1));
        }
        if ((plateau.getCase(i-1,j-1)!=null &&plateau.getCase(i-1,j-1).getCouleur()!=getCouleur())&&j-1>0&&i-1>0){
            tableau.add(new Position(i-1,j-1));
        }
        return tableau;
    }

    public ArrayList<Position> getDeplacementPossibleEchec(Plateau plateau) 
    {
        ArrayList <Position> tableau = new ArrayList<Position>();
        int i = getPosition().getX();
        int j = getPosition().getY();
        if ((plateau.getCase(i,j-1)==null )&&j-1>0){
            tableau.add(new Position(i,j-1));
        }
        if ((plateau.getCase(i,j-2)==null && plateau.getCase(i,j-1)==null)&&j-2>0&&j==7){
            tableau.add(new Position(i,j-2));
        }
        if (j-1>0&&i+1<9){
                tableau.add(new Position(i+1,j-1));
        }
        if (j-1>0&&i-1>0){
                tableau.add(new Position(i-1,j-1));
        }
        return tableau;
    }
}