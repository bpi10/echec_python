/*******************************/ 
/*           classe Roi        */
/*         Pierre Brenel       */
/*             ECHEC           */
/*******************************/
import java.util.ArrayList;

public class Roi extends Piece{

    public Roi() {
        setCouleur('B');
        setPosition(new Position("E1"));
    }

    public Roi(char couleur, String position) {
        setCouleur(couleur);
        setPosition(new Position(position));
    }
    public String getType() {
        return "roi";
    }

    public ArrayList<Position> getDeplacementPossible(Plateau plateau) {
        ArrayList <Position> tableau = new ArrayList<Position>();
        int i = getPosition().getX();
        int j = getPosition().getY();
        if ((plateau.getCase(i+1,j+1)==null || plateau.getCase(i+1,j+1).getCouleur()!= getCouleur())&& i+1<=8 && j+1<=8)
            {
                    if (plateau.getCase(i+1,j+1) == null){
                        tableau.add(new Position(i+1,j+1));
                    }
                    else if(plateau.getCase(i+1,j+1).getCouleur()!= getCouleur()){
                        tableau.add(plateau.getCase(i+1,j+1).getPosition());
                    }
                }
            
        if ((plateau.getCase(i+1,j)==null || plateau.getCase(i+1,j).getCouleur()!= getCouleur())&&i+1<=8){
                if (plateau.getCase(i+1,j) == null){
                    tableau.add(new Position(i+1,j));
                }
                else if(plateau.getCase(i+1,j).getCouleur()!= getCouleur()){
                    tableau.add(plateau.getCase(i+1,j).getPosition());
                }
            }
        if ((plateau.getCase(i+1,j-1)==null || plateau.getCase(i+1,j-1).getCouleur()!= getCouleur())&&i+1<9&&j-1>0){
                if (plateau.getCase(i+1,j-1) == null){
                    tableau.add(new Position(i+1,j-1));
                }
                else if(plateau.getCase(i+1,j-1).getCouleur()!= getCouleur()){
                    tableau.add(plateau.getCase(i+1,j-1).getPosition());
                }
            }
        if ((plateau.getCase(i,j-1)==null || plateau.getCase(i,j-1).getCouleur()!= getCouleur())&&j-1>0){
                if (plateau.getCase(i,j-1) == null){
                    tableau.add(new Position(i,j-1));
                }
                else if(plateau.getCase(i,j-1).getCouleur()!= getCouleur()){
                    tableau.add(plateau.getCase(i,j-1).getPosition());
                }
            }
        if ((plateau.getCase(i,j+1)==null || plateau.getCase(i,j+1).getCouleur()!= getCouleur())&&j+1<=8){
                if (plateau.getCase(i,j+1) == null) {
                    tableau.add(new Position(i,j+1));
                }
                else if(plateau.getCase(i,j+1).getCouleur()!= getCouleur()){
                    tableau.add(plateau.getCase(i,j+1).getPosition());
                }
            }
            if ((plateau.getCase(i-1,j+1)==null || plateau.getCase(i-1,j+1).getCouleur()!= getCouleur())&&j+1<=8&&i-1>0) {
                if (plateau.getCase(i-1,j+1) == null) {
                    tableau.add(new Position(i-1,j+1));
                }
                else if(plateau.getCase(i-1,j+1).getCouleur()!= getCouleur()){
                    tableau.add(plateau.getCase(i-1,j+1).getPosition());
                }
            }
        if ((plateau.getCase(i-1,j)==null || plateau.getCase(i-1,j).getCouleur()!= getCouleur())&&i-1>0){
                if (plateau.getCase(i-1,j) == null) {
                    tableau.add(new Position(i-1,j));
                }
                else if(plateau.getCase(i-1,j).getCouleur()!= getCouleur()){
                    tableau.add(plateau.getCase(i-1,j).getPosition());
                }
            }
        if ((plateau.getCase(i-1,j-1)==null || plateau.getCase(i-1,j-1).getCouleur()!= getCouleur())&&i-1>0&&j-1>0){
                if (plateau.getCase(i-1,j-1) == null){
                    tableau.add(new Position(i-1,j-1));
                }
                else if(plateau.getCase(i-1,j-1).getCouleur()!= getCouleur()){
                    tableau.add(plateau.getCase(i-1,j-1).getPosition());
                }
            }
        return tableau;
    }


    public ArrayList<Position> getDeplacementPossibleEchec(Plateau plateau) {
        ArrayList <Position> tableau = new ArrayList<Position>();
        int i=getPosition().getX();
        int j = getPosition().getY();
        if ((plateau.getCase(i+1,j+1)==null || plateau.getCase(i+1,j+1).getCouleur()!= getCouleur())&& i+1<=8 && j+1<=8){
                    if (plateau.getCase(i+1,j+1) == null){
                        tableau.add(new Position(i+1,j+1));
                    }
                    else if(plateau.getCase(i+1,j+1).getCouleur()!= getCouleur()){
                        tableau.add(plateau.getCase(i+1,j+1).getPosition());
                    }
                }
            
        if ((plateau.getCase(i+1,j)==null || plateau.getCase(i+1,j).getCouleur()!= getCouleur())&&i+1<9){
                if (plateau.getCase(i+1,j) == null){
                    tableau.add(new Position(i+1,j));
                }
                else if(plateau.getCase(i+1,j).getCouleur()!= getCouleur()){
                    tableau.add(plateau.getCase(i+1,j).getPosition());
                }
            }
        if ((plateau.getCase(i+1,j-1)==null || plateau.getCase(i+1,j-1).getCouleur()!= getCouleur())&&i+1<9&&j-1>0)
            {
                if (plateau.getCase(i+1,j-1) == null) {
                    tableau.add(new Position(i+1,j-1));
                }
                else if(plateau.getCase(i+1,j-1).getCouleur()!= getCouleur()){
                    tableau.add(plateau.getCase(i+1,j-1).getPosition());
                }
            }
        if ((plateau.getCase(i,j-1)==null || plateau.getCase(i,j-1).getCouleur()!= getCouleur())&&j-1>0){
                if (plateau.getCase(i,j-1) == null){
                    tableau.add(new Position(i,j-1));
                }
                else if(plateau.getCase(i,j-1).getCouleur()!= getCouleur())
                {
                    tableau.add(plateau.getCase(i,j-1).getPosition());
                }
            }
        if ((plateau.getCase(i,j+1)==null || plateau.getCase(i,j+1).getCouleur()!= getCouleur())&&j+1<9){
                if (plateau.getCase(i,j+1) == null){
                    tableau.add(new Position(i,j+1));
                }
                else if(plateau.getCase(i,j+1).getCouleur()!= getCouleur()){
                    tableau.add(plateau.getCase(i,j+1).getPosition());
                }
            }
            if ((plateau.getCase(i-1,j+1)==null || plateau.getCase(i-1,j+1).getCouleur()!= getCouleur())&&j+1<9&&i-1>0){
                if (plateau.getCase(i-1,j+1) == null){
                    tableau.add(new Position(i-1,j+1));
                }
                else if(plateau.getCase(i-1,j+1).getCouleur()!= getCouleur()) {
                    tableau.add(plateau.getCase(i-1,j+1).getPosition());
                }
            }
        if ((plateau.getCase(i-1,j)==null || plateau.getCase(i-1,j).getCouleur()!= getCouleur())&&i-1>0){
                if (plateau.getCase(i-1,j) == null){
                    tableau.add(new Position(i-1,j));
                }
                else if(plateau.getCase(i-1,j).getCouleur()!= getCouleur()){
                    tableau.add(plateau.getCase(i-1,j).getPosition());
                }
            }
        if ((plateau.getCase(i-1,j-1)==null || plateau.getCase(i-1,j-1).getCouleur()!= getCouleur())&&i-1>0&&j-1>0){
                if (plateau.getCase(i-1,j-1) == null){
                    tableau.add(new Position(i-1,j-1));
                }
                else if(plateau.getCase(i-1,j-1).getCouleur()!= getCouleur()) {
                    tableau.add(plateau.getCase(i-1,j-1).getPosition());
                }
            }
        return tableau;
    }
}