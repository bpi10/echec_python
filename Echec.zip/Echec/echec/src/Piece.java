/*******************************/ 
/*         classe Piece        */
/*         Pierre Brenel       */
/*             ECHEC           */
/*******************************/
import java.util.ArrayList;

public abstract class Piece {
    private char couleur;
    private Position position;

    // Un constructeur par défaut qui créera un pion blanc en A2
    public Piece()
    {
        this.couleur='B';
        this.position= new Position("A2");
    }

    // Un constructeur par copie
    Piece(Piece pi) {
        this.couleur = pi.couleur;
        this.position = new Position(pi.position);
    }
    
    // Un constructeur prenant en paramètre le type de la pièce, 
    // une couleur et une position sous la forme de deux entiers.
    public Piece(char couleur, int x , int y) {
        System.out.println("Je suis un constructeur de la classe Piece");
        this.couleur = couleur;
        this.position=new Position(x, y);
    }

    // Un constructeur prenant en paramètre le type de la pièce, 
    // une couleur et une position sous la forme d’un objet de type Position
    public Piece(char couleur, Position obj) {
        this.couleur = couleur;
        this.position = new Position(obj);
    }

    // Un constructeur prenant en paramètre le type de la pièce, une couleur et une position
    // sous la forme d’une chaine de caractère identifiant une case à la manière d’un échiquier
    // (type "A4" ou "E3").
    public Piece(char couleur, String position)
    {
        this.couleur = couleur;
        this.position = new Position(position);
    }

    // Getter de Couleur
    public char getCouleur() {
        return this.couleur;
    }

    // Getter de Position
    public Position getPosition() {
        return this.position;
    }

    // Getter de Type
    public abstract String getType();
    

    // Setter de Couleur 
    public char setCouleur(char couleur) {
        return this.couleur = couleur;
    }

    // Setter de Position 
    public Position setPosition(Position p) {
        return this.position = p;
    }
    
    // Méthode getNomCourt
    public String getNomCourt() {
        String typecourt;
        typecourt = "untype";
        if (getType() == "pion")
        {
            typecourt="Pi";
        }
        else if (getType() == "cavalier")
        {
            typecourt = "Ca";
        }
        else if (getType() == "tour")
        {
            typecourt = "To";
        }
        else if (getType() == "fou")
        {
            typecourt = "Fo";
        }
        else if (getType() == "dame")
        {
            typecourt = "Da";
        }
        else if (getType() == "roi")
        {
            typecourt = "Ro";
        }
        return (typecourt + this.couleur);
    }

    // Métode getNomLong
    public String getNomLong() {
        return this.getType() + '_' + this.couleur;
    }

    // La méthode equals prenant un Object en paramètre
    @Override
    public boolean equals(Object obj) {
        if(this == obj) return true;
        if (!(obj instanceof Piece)) return false;
        Piece pi = (Piece) obj; // transforme obj en position

        // if (this.type != (pi.type)) return false;
        if (this.couleur != (pi.couleur)) return false;
        if (this.position != (pi.position)) return false;
        return true;
    }

    @Override
    public String toString() {   
        String couleurlong;
        if (this.couleur == 'N') {
            couleurlong = "noir";
        }
        else {
            couleurlong = "blanc";
        }
        return (getType() + " " + couleurlong + " en " + this.position);
       
    }

    public abstract ArrayList<Position> getDeplacementPossible(Plateau plateau);

    public abstract ArrayList<Position> getDeplacementPossibleEchec(Plateau plateau);
}

