/*******************************/ 
/*         classe Fou          */
/*         Pierre Brenel       */
/*             ECHEC           */
/*******************************/
import java.util.ArrayList;

public class Fou extends Piece{

    public Fou()
    {
        setCouleur('B');
        setPosition(new Position("C1"));
    }

    public Fou(char c , String pos)
    {
        setCouleur(c);
        setPosition(new Position(pos));
    }

    public String getType()
    {
        return "fou";
    }
    public ArrayList<Position> getDeplacementPossible(Plateau p) 
    {
        ArrayList <Position> tab = new ArrayList<Position>();
        int i = getPosition().getX();
        int j = getPosition().getY();
        int compteur = 0;
        j = j + 1;
        i = i + 1;
        while((p.getCase(i,j) == null || p.getCase(i,j).getCouleur()!= getCouleur()) && compteur  ==  0 && j<9 && i<9 )
        {
            if (p.getCase(i,j) == null)
            {
                tab.add(new Position(i,j));
                j = j + 1;
                i = i + 1;
            }
            else if(p.getCase(i,j).getCouleur()!= getCouleur())
            {
                compteur = 1;
                tab.add(p.getCase(i,j).getPosition());
                j = j + 1;
                i = i + 1;
            }
            else
            {
                compteur = 0;
                tab.add(p.getCase(i,j).getPosition());
                j = j + 1;
                i = i + 1;
            }
        }
        i = getPosition().getX();
        j = getPosition().getY();
        compteur = 0;
        j = j - 1 ;
        i = i - 1 ;
        while((p.getCase(i,j) == null || p.getCase(i,j).getCouleur()!= getCouleur()) && compteur == 0 && j>0 && i>0 )
        {
            if (p.getCase(i,j) == null)
            {
                tab.add(new Position(i,j));
                j = j - 1 ;
                i = i - 1 ;
            }
            else if(p.getCase(i,j).getCouleur()!= getCouleur())
            {
                compteur = 1;
                tab.add(p.getCase(i,j).getPosition());
                j = j - 1 ;
                i = i - 1 ;
            }
            else
            {
                compteur = 0;
                tab.add(p.getCase(i,j).getPosition());
                j = j - 1 ;
                i = i - 1 ;
            }
        }
        i = getPosition().getX();
        j = getPosition().getY();
        compteur = 0;
        j = j - 1 ;
        i = i + 1;
        while((p.getCase(i,j) == null || p.getCase(i,j).getCouleur()!= getCouleur()) && compteur == 0 && j>0 && i<9 )
        {
            if (p.getCase(i,j) == null)
            {
                tab.add(new Position(i,j));
                j = j - 1 ;
                i = i + 1;
            }
            else if(p.getCase(i,j).getCouleur() != getCouleur())
            {
                compteur = 1;
                tab.add(p.getCase(i,j).getPosition());
                j = j - 1;
                i = i + 1;
            }
            else
            {
                compteur = 0;
                tab.add(p.getCase(i,j).getPosition());
                j = j - 1;
                i = i + 1;
            }
        }
        i = getPosition().getX();
        j = getPosition().getY();
        compteur = 0;
        j = j + 1 ;
        i = i - 1;
        while((p.getCase(i,j) == null || p.getCase(i,j).getCouleur()!= getCouleur()) && compteur == 0 && j<9 && i>0 )
        {
            if (p.getCase(i,j) == null)
            {
                tab.add(new Position(i,j));
                j = j + 1 ;
                i = i - 1;
            }
            else if(p.getCase(i,j).getCouleur() != getCouleur())
            {
                compteur = 1;
                tab.add(p.getCase(i,j).getPosition());
                j = j + 1 ;
                i = i - 1;
            }
            else
            {
                compteur = 0;
                tab.add(p.getCase(i,j).getPosition());
                j = j + 1 ;
                i = i - 1;
            }
        }
        return tab;
    }

    public ArrayList<Position> getDeplacementPossibleEchec(Plateau p) 
    {
        ArrayList <Position> tab = new ArrayList<Position>();
        int i = getPosition().getX();
        int j = getPosition().getY();
        int compteur = 0;
        j = j + 1;
        i = i + 1;
        while((p.getCase(i,j) == null || p.getCase(i,j).getCouleur()!= getCouleur()) && compteur  ==  0 && j<9 && i<9 )
        {
            if (p.getCase(i,j) == null)
            {
                tab.add(new Position(i,j));
                j = j + 1;
                i = i + 1;
            }
            else if(p.getCase(i,j).getCouleur()!= getCouleur())
            {
                compteur = 1;
                tab.add(p.getCase(i,j).getPosition());
                j = j + 1;
                i = i + 1;
            }
            else
            {
                compteur = 0;
                tab.add(p.getCase(i,j).getPosition());
                j = j + 1;
                i = i + 1;
            }
        }
        i = getPosition().getX();
        j = getPosition().getY();
        compteur = 0;
        j = j - 1 ;
        i = i - 1 ;
        while((p.getCase(i,j) == null || p.getCase(i,j).getCouleur()!= getCouleur()) && compteur == 0 && j>0 && i>0 )
        {
            if (p.getCase(i,j) == null)
            {
                tab.add(new Position(i,j));
                j = j - 1 ;
                i = i - 1 ;
            }
            else if(p.getCase(i,j).getCouleur()!= getCouleur())
            {
                compteur = 1;
                tab.add(p.getCase(i,j).getPosition());
                j = j - 1 ;
                i = i - 1 ;
            }
            else
            {
                compteur = 0;
                tab.add(p.getCase(i,j).getPosition());
                j = j - 1 ;
                i = i - 1 ;
            }
        }
        i = getPosition().getX();
        j = getPosition().getY();
        compteur = 0;
        j = j - 1 ;
        i = i + 1;
        while((p.getCase(i,j) == null || p.getCase(i,j).getCouleur()!= getCouleur()) && compteur == 0 && j>0 && i<9 )
        {
            if (p.getCase(i,j) == null)
            {
                tab.add(new Position(i,j));
                j = j - 1 ;
                i = i + 1;
            }
            else if(p.getCase(i,j).getCouleur() != getCouleur())
            {
                compteur = 1;
                tab.add(p.getCase(i,j).getPosition());
                j = j - 1;
                i = i + 1;
            }
            else
            {
                compteur = 0;
                tab.add(p.getCase(i,j).getPosition());
                j = j - 1;
                i = i + 1;
            }
        }
        i = getPosition().getX();
        j = getPosition().getY();
        compteur = 0;
        j = j + 1 ;
        i = i - 1;
        while((p.getCase(i,j) == null || p.getCase(i,j).getCouleur()!= getCouleur()) && compteur == 0 && j<9 && i>0 )
        {
            if (p.getCase(i,j) == null)
            {
                tab.add(new Position(i,j));
                j = j + 1 ;
                i = i - 1;
            }
            else if(p.getCase(i,j).getCouleur() != getCouleur())
            {
                compteur = 1;
                tab.add(p.getCase(i,j).getPosition());
                j = j + 1 ;
                i = i - 1;
            }
            else
            {
                compteur = 0;
                tab.add(p.getCase(i,j).getPosition());
                j = j + 1 ;
                i = i - 1;
            }
        }
        return tab;
    }
}