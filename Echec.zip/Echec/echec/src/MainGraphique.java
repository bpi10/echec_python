/*******************************/ 
/*      classe MainGraphique   */
/*         Pierre Brenel       */
/*             ECHEC           */
/*******************************/
import MG2D.*;
import MG2D.geometrie.*;

class MainGraphique {

    public static void main(String[] args){
        
        Plateau p = new Plateau();
        Fenetre f = new Fenetre("Bpi's chess", 600, 600); // 800 * 800 CAR JEU D ECHEC -> 8 * 8 et avec pieces / cases taille 10
        for(int x = 0; x < 8; x++){
            for(int y = 0; y < 8; y++) {
                Carre carre = new Carre(new Couleur(66, 75, 84), new Point(x*150, y*150), 75, true);
                f.ajouter(carre);
                Carre carre1 = new Carre(new Couleur(66, 75, 84), new Point(((x*150)+75), ((y*150)+75)), 75, true);
                f.ajouter(carre1);
            }
        }
        for(int x = 0 ; x < 8 ; x++) {
            for(int y = 0 ; y < 8 ; y++) {
                if(p.getCase(new Position(x,y)) !=null ){
                    f.ajouter(new Texture("images/"+p.getCase(new Position(x,y)).getNomLong()+".png",new Point((x*75),(y*75)), 75, 75));
                    f.rafraichir();
                }
                f.rafraichir();
            }
        }
        Souris souris = f.getSouris();
    }
}

// CTRL K + C POUR COMMENTAIRE (EN SELECTIONNANT)