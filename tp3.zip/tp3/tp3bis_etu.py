#***********************************#
#              TP3 STATS            #
#            BRENEL Pierre          #
#***********************************#

# Sources
# https://moncoachdata.com/blog/guide-bibliotheque-pandas/
# http://www.python-simple.com/python-pandas/fonctions-dataframe.php

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Partie 1

# pour lire un tableau -> dataFrame = pd.read_excel('TP3.xlsx', index_col=['insertion 12 mois'])


# tableau avec ce qui est rentré dans les colonnes.
df= {
    'insertion 12 mois': [92,94,94,94,86],
    'emploi 12 mois': [81,83,85,85,69],
    'emplois 6 mois': [64,70,76,74,62]
}

# 1ere colonne
colonne = ['2015','2016','2017','2018','2019']
df_complet = pd.DataFrame(df, index = colonne)
print("Le dataframe est: \n")
print(df_complet,"\n")


# afficher une colonne
print("La colonne -> insertion 12 mois du dataframe est: \n")
print(df_complet['insertion 12 mois'])


# calculer la moyenne de la colonne insertion à 12 mois
mean_df_ins_12_mois = df_complet['insertion 12 mois'].mean()
print("la moyenne de la colonne -> insertion 12 mois est:", mean_df_ins_12_mois,"\n")


# puis celle de de toutes les colonnes (paramètre axis=0)
mean_df = df_complet.mean()
print("la moyenne de toutes les colonnes sont:\n",mean_df,"\n")


# calculer la médiane et l’écart-type de la colonne insertion à 12 mois
median_df_ins_12_mois = df_complet['insertion 12 mois'].median()
print("la moyenne de la colonne -> insertion 12 mois est:", median_df_ins_12_mois,"\n")
ecarttype_df_ins_12_mois = df_complet['insertion 12 mois'].std()
print("la moyenne de la colonne -> insertion 12 mois est:", ecarttype_df_ins_12_mois,"\n")


# puis celle de de toutes les colonnes (paramètre axis=0)
df1 = df_complet.median(axis = 0)
print("les medianes de toutes les colonnes sont: \n", df1, "\n")
df2 = df_complet.std(axis = 0)
print("les ecart-type de toutes les colonnes sont: \n", df2)


# En important matplotlib.pyplot, représenter les données ci-dessus
# axis = df_complet.plot.bar(rot = 0)
# plt.show()


# Partie 2

notes = { 
    'maths': [3,10,11,16,2], 
    'fran': [12,5,14,7,18],
    'info': [13,15,12,9,11],
    'ang': [19,17,6,11,9]
    }
liste=['Alain','Bernard','Clarisse','David','Elodie'] 
notes_tout = pd.DataFrame (notes,index=liste )
print(notes_tout)
coef= [2, 1, 4, 1]


# moyenne = np.average(notes_tout, weights=coef)
# Rappeler la formule qui permet de calculer la variance comme une moyenne.
# Récupérer le fichier python tp3bis_etu.

# Calculer la moyenne de l’étudiant ‘Alain’.
mean_df_alain = notes_tout['Alain'].mean()
print("la moyenne de la colonne -> Alain est:", mean_df_alain,"\n")
# puis celui de l’ensemble des étudiants en utilisant une boucle.


# Calculer l’écart-type pour Alain (pas beaucoup de sens, on peut le remarquer).


# Calculer la moyenne et l’écart-type de l’ensemble des matières
