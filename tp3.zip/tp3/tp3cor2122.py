#Anne Pacou
#année 2021-2022
import pandas as pd
import matplotlib.pyplot as plt

#question 1
Tableau={"insertion 12 mois":[92,94,94,94,86],
         "emploi 12 mois":[81,83,85,85,69],
         "emploi 6 mois":[64,70,76,74,62]}

annee=[2015,2016,2017,2018,2019]

donnee=pd.DataFrame(Tableau,index=annee)

#question 2
print(donnee["insertion 12 mois"])
print(donnee.loc[2015])

#question 3
print("moyenne " + str(donnee["insertion 12 mois"].mean()))
print("\nmoyenne tout \n" + str(donnee.mean(axis=0)))

#question 4
print("mediane  " + str(donnee["insertion 12 mois"].median()))
print("ecart-type " + str(donnee["insertion 12 mois"].std()))

print("\nmediane tout \n" + str(donnee.median(axis=0)))
print("\necart-type tout \n" + str(donnee.std(axis=0)))

#exercice 2
plt.plot(donnee)
plt.show()