#Anne Pacou
#année 2021-2022

import pandas as pd
import numpy as np
from math import sqrt
# question 1 var=moyenne(xi-moyenne(xi))**2

# question 2
notes = { 
    'maths': [3,10,11,16,2], 
    'fran': [12,5,14,7,18],
    'info': [13,15,12,9,11],
    'ang': [19,17,6,11,9]
    }
liste=['Alain','Bernard','Clarisse','David','Elodie'] 

notes_tout = pd.DataFrame ( notes,index=liste )
print(notes_tout)
coef= [2, 1, 4, 1]

#question 3
moyenne_alain = np.average(notes_tout.loc['Alain'], weights=coef)
print('moyenne alain : '+ str(moyenne_alain))
print("\nmoyenne de tous : \n")
for i in liste:
    moyenne = np.average(notes_tout.loc[i], weights=coef)
    print(i," ", str(moyenne))

#question 4
ecart=np.average((notes_tout.loc['Alain']-moyenne_alain)**2, weights=coef)
print("\nécart-type Alain : " + str(sqrt(ecart)))

#question 5
print("\nmoyenne des matieres : \n"+ str(notes_tout.mean(axis=0)))
print("\necart-type des matieres : \n"+ str(notes_tout.std(axis=0)))